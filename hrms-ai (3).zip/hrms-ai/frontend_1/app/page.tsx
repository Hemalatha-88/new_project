"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

const roles = [
  { id: "admin", title: "Management", sub: "Admin", defaultEmail: "admin@peopleos.in" },
  { id: "manager", title: "Senior Manager", sub: "Team Lead", defaultEmail: "manager@peopleos.in" },
  { id: "recruiter", title: "HR Recruiter", sub: "Talent Team", defaultEmail: "recruiter@peopleos.in" },
  { id: "employee", title: "Employee", sub: "Staff Member", defaultEmail: "employee@peopleos.in" },
];

export default function LoginPage() {
  const router = useRouter();
  const [isRegistering, setIsRegistering] = useState(false);
  const [selectedRole, setSelectedRole] = useState("admin");
  
  // Form parameters
  const [name, setName] = useState("");
  const [department, setDepartment] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  
  // UI States
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  // ----------------------------------
  // Submit Flow: Login API Call
  // ----------------------------------
  const handleLogin = async () => {
    setError("");
    setMessage("");
    setLoading(true);

    try {
      const response = await fetch("https://hrms-ai-5.onrender.com/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Login verification failed");
      }

      // Save verified security session details (Storing multiple variations to guarantee matching keys)
      localStorage.setItem("role", data.role || selectedRole);
      localStorage.setItem("token", data.token || "mock-jwt-token-key");
      
      localStorage.setItem("email", data.email || email);
      localStorage.setItem("userEmail", data.email || email);
      
      localStorage.setItem("name", data.name || "User");
      localStorage.setItem("userName", data.name || "User");
      
      // Navigate straight to the dashboard frame
      router.push("/dashboard");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // ----------------------------------
  // Submit Flow: Registration API Call
  // ----------------------------------
  const handleRegister = async () => {
    setError("");
    setMessage("");
    setLoading(true);

    try {
      const response = await fetch("https://hrms-ai-5.onrender.com/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name || "Anonymous User",
          department: department || "Operations",
          email,
          password,
          role: selectedRole,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Registration rejected");
      }

      setMessage("Registration successful! You can now switch to Sign In.");
      // Clear registration inputs
      setName("");
      setDepartment("");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const currentRoleData = roles.find((r) => r.id === selectedRole);

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0a0f1e] p-6">
      <div className="w-full max-w-md bg-[#111827] border border-white/10 rounded-2xl p-10">
        
        {/* Core Layout Identity Header */}
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 bg-blue-500 rounded-xl flex items-center justify-center text-white font-bold text-lg">H</div>
          <div>
            <div className="text-white font-semibold text-lg">PeopleOS</div>
            <div className="text-gray-500 text-xs tracking-widest uppercase">AI-Powered HRMS</div>
          </div>
        </div>

        <span className="inline-block text-xs px-3 py-1 rounded-full bg-blue-500/20 text-blue-400 mb-6">
          Strategic HR Command Center
        </span>

        <h1 className="text-2xl font-semibold text-white mb-1">
          {isRegistering ? "Create an account" : "Welcome back"}
        </h1>
        <p className="text-gray-500 text-sm mb-6">
          {isRegistering ? "Register your organizational profile secure tier" : "Sign in to your HR intelligence platform"}
        </p>

        {/* System Access Role Selector Grid */}
        <div className="grid grid-cols-2 gap-2 mb-6">
          {roles.map((role) => (
            <button
              key={role.id}
              type="button"
              onClick={() => { setSelectedRole(role.id); setError(""); setMessage(""); }}
              className={`text-left p-3 rounded-xl border transition-all ${
                selectedRole === role.id
                  ? "border-blue-500 bg-blue-500/15"
                  : "border-white/10 hover:border-blue-500/50"
              }`}
            >
              <div className="flex justify-between items-start">
                <div>
                  <div className="text-white text-xs font-semibold">{role.title}</div>
                  <div className="text-gray-500 text-xs mt-0.5">{role.sub}</div>
                </div>
                {selectedRole === role.id && (
                  <div className="w-2 h-2 rounded-full bg-blue-500 mt-1" />
                )}
              </div>
            </button>
          ))}
        </div>

        {/* Unified Credentials Input Workspace */}
        <div className="space-y-3">
          {isRegistering && (
            <>
              <div>
                <label className="text-xs text-gray-400 mb-1.5 block">Full Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="John Doe"
                  className="w-full bg-[#1f2937] border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="text-xs text-gray-400 mb-1.5 block">Department Assignment</label>
                <input
                  type="text"
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  placeholder="Engineering"
                  className="w-full bg-[#1f2937] border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm outline-none focus:border-blue-500"
                />
              </div>
            </>
          )}

          <div>
            <label className="text-xs text-gray-400 mb-1.5 block">Email address</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder={currentRoleData?.defaultEmail}
              className="w-full bg-[#1f2937] border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm outline-none focus:border-blue-500 placeholder-gray-600"
            />
          </div>
          <div>
            <label className="text-xs text-gray-400 mb-1.5 block">Secure Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full bg-[#1f2937] border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm outline-none focus:border-blue-500"
            />
          </div>
        </div>

        {/* Response Notification Windows */}
        {error && <p className="text-red-400 text-xs mt-3 bg-red-400/10 border border-red-400/20 px-3 py-2 rounded-lg">{error}</p>}
        {message && <p className="text-green-400 text-xs mt-3 bg-green-400/10 border border-green-400/20 px-3 py-2 rounded-lg">{message}</p>}

        {/* Dynamic Action Submission Executer */}
        <button
          onClick={isRegistering ? handleRegister : handleLogin}
          disabled={loading}
          className="w-full mt-5 bg-blue-500 hover:bg-blue-600 disabled:bg-blue-800 disabled:cursor-not-allowed text-white font-semibold py-3 rounded-xl text-sm transition-all"
        >
          {loading ? "Processing network handshake..." : isRegistering ? "Execute Core Registration →" : "Sign in to Dashboard →"}
        </button>

        {/* View Layout Toggle Controller */}
        <div className="mt-5 pt-4 border-t border-white/5 text-center">
          <button
            onClick={() => { setIsRegistering(!isRegistering); setError(""); setMessage(""); }}
            className="text-xs text-blue-400 hover:text-blue-300 font-medium transition-colors"
          >
            {isRegistering ? "Already have an encrypted account? Sign In" : "Need to run a scalability registration test? Sign Up"}
          </button>
        </div>

      </div>
    </div>
  );
}