"use client";

import React, { useEffect, useState, useRef } from "react";
import { useParams, useRouter } from "next/navigation";

export default function RealTimeVoiceInterviewPage() {
  const params = useParams();
  const router = useRouter();
  const token = params?.token as string;

  const [candidateName, setCandidateName] = useState<string>("");
  const [targetRole, setTargetRole] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Voice & Conversation States
  const [currentQuestion, setCurrentQuestion] = useState<string>("");
  const [isListening, setIsListening] = useState<boolean>(false);
  const [transcript, setTranscript] = useState<string>("");
  const [isCompleted, setIsCompleted] = useState<boolean>(false);
  const [submittingTurn, setSubmittingTurn] = useState<boolean>(false);

  // Web Speech API References
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    if (!token) return;

    // Initialize Web Speech Recognition
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const rec = new SpeechRecognition();
      rec.continuous = true;
      rec.interimResults = true;
      rec.lang = "en-US";

      rec.onresult = (event: any) => {
        let currentTranscript = "";
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            currentTranscript += event.results[i][0].transcript;
          }
        }
        if (currentTranscript) {
          setTranscript((prev) => prev + " " + currentTranscript);
        }
      };

      rec.onerror = (e: any) => {
        console.error("Speech Recognition Error:", e);
        setIsListening(false);
      };

      rec.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = rec;
    } else {
      setError("Your web browser does not support voice speech recognition functionality. Please use Google Chrome.");
    }

    // Fetch initial state and question
    fetch(`https://hrms-ai-5.onrender.com/api/interview/${token}/start`)
      .then((res) => res.json())
      .then((data) => {
        if (data.error) throw new Error(data.error);
        setCandidateName(data.candidateName);
        setTargetRole(data.targetRole);
        setCurrentQuestion(data.nextQuestion);
        if (data.status === "Completed") setIsCompleted(true);
        setLoading(false);
        
        // Speak out initial question automatically
        speakText(data.nextQuestion);
      })
      .catch((err) => {
        setError(err.message || "Failed to load session details.");
        setLoading(false);
      });
  }, [token]);

  // Function to make the AI speak aloud
  const speakText = (text: string) => {
    if (typeof window !== "undefined" && window.speechSynthesis) {
      window.speechSynthesis.cancel(); // Stop any ongoing speech
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.0;
      utterance.pitch = 1.0;
      window.speechSynthesis.speak(utterance);
    }
  };

  // Toggle Microphone listener
  const toggleListening = () => {
    if (!recognitionRef.current) return;

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      setTranscript("");
      recognitionRef.current.start();
      setIsListening(true);
    }
  };

  // Send answer to backend and fetch the next response or final completion
  const handleSendAnswer = async () => {
    if (!transcript.trim()) return;
    
    if (isListening && recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
    }

    setSubmittingTurn(true);
    try {
      const response = await fetch(`https://hrms-ai-5.onrender.com/api/interview/${token}/process-turn`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: currentQuestion,
          answer: transcript.trim()
        })
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Turn execution failure.");

      if (data.status === "Completed") {
        setIsCompleted(true);
        speakText("Thank you. The automated evaluation screen has concluded. Your metrics have been successfully transmitted back to HR.");
      } else {
        setCurrentQuestion(data.nextQuestion);
        setTranscript("");
        speakText(data.nextQuestion); // Speak out the dynamic follow-up question
      }
    } catch (err: any) {
      alert(err.message || "Error communication loop error.");
    } finally {
      setSubmittingTurn(false);
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-950 text-white">
        <p className="text-slate-400 font-medium animate-pulse">Initializing Dynamic Audio Interface Core...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-950 text-white p-4">
        <div className="max-w-md w-full bg-slate-900 p-6 rounded-xl border border-red-500/30 text-center space-y-4">
          <p className="text-red-400 text-sm">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <main className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-4 md:p-8">
      <div className="max-w-2xl w-full bg-slate-900 rounded-2xl border border-slate-800 shadow-2xl p-6 md:p-8 space-y-8">
        
        {/* Header Display */}
        <div className="border-b border-slate-800 pb-4 flex justify-between items-start">
          <div>
            <h1 className="text-xl font-bold text-white">{candidateName}</h1>
            <p className="text-xs text-indigo-400 font-medium">{targetRole} Interview Screen</p>
          </div>
          <span className="bg-indigo-500/10 text-indigo-400 text-[10px] px-2.5 py-1 rounded-full uppercase tracking-wider font-bold">
            Live AI Voice Session
          </span>
        </div>

        {isCompleted ? (
          <div className="text-center py-12 space-y-4">
            <div className="w-16 h-16 bg-emerald-500/10 text-emerald-400 flex items-center justify-center rounded-full text-2xl font-bold mx-auto">✓</div>
            <h2 className="text-xl font-bold text-white">Interview Finalized</h2>
            <p className="text-slate-400 text-sm max-w-sm mx-auto leading-relaxed">
              Your voice metrics, vocabulary detail metrics, and response metrics have been analyzed and locked directly into the HR dashboard.
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            
            {/* The Question Asked by AI */}
            <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 relative">
              <h3 className="text-[11px] font-bold uppercase text-indigo-400 tracking-widest mb-2">AI Interviewer Question:</h3>
              <p className="text-sm md:text-base text-slate-200 leading-relaxed font-medium">
                {currentQuestion}
              </p>
              <button 
                onClick={() => speakText(currentQuestion)}
                className="mt-3 text-xs text-slate-400 hover:text-white underline transition block"
              >
                🔊 Replay Question Audio
              </button>
            </div>

            {/* Answer Box Showing Real-time Speech-to-Text */}
            <div className="space-y-2">
              <h3 className="text-[11px] font-bold uppercase text-slate-400 tracking-widest">Your Spoken Response:</h3>
              <div className="w-full min-h-[120px] bg-slate-950 border border-slate-800 rounded-xl p-4 text-sm text-slate-300 leading-relaxed relative">
                {transcript ? (
                  transcript
                ) : (
                  <span className="text-slate-600 italic">Click the microphone button below and start speaking your answer clearly...</span>
                )}
                
                {isListening && (
                  <span className="absolute bottom-3 right-3 flex h-2 w-2 rounded-full bg-red-500 animate-ping" />
                )}
              </div>
            </div>

            {/* Microphones Control & Submit Actions */}
            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <button
                onClick={toggleListening}
                className={`flex-1 py-3 px-4 rounded-xl font-semibold text-sm transition flex items-center justify-center gap-2 ${
                  isListening 
                    ? "bg-red-600 hover:bg-red-500 text-white animate-pulse" 
                    : "bg-slate-800 hover:bg-slate-700 text-slate-200"
                }`}
              >
                {isListening ? "⏹ Stop Listening" : "🎤 Turn Mic ON & Answer"}
              </button>

              <button
                onClick={handleSendAnswer}
                disabled={submittingTurn || !transcript.trim()}
                className="flex-1 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 text-white font-semibold text-sm py-3 px-4 rounded-xl transition flex items-center justify-center gap-2 disabled:cursor-not-allowed"
              >
                {submittingTurn ? (
                  <span>AI analyzing response...</span>
                ) : (
                  <span>Send Answer & Next Question ➔</span>
                )}
              </button>
            </div>

          </div>
        )}

      </div>
    </main>
  );
}