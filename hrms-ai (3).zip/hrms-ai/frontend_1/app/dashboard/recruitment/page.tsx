"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";

interface Job {
  id: number;
  role: string;
  mustHave: string[];
  niceToHave: string[];
  budgetMax: string;
}

interface Candidate {
  id: number;
  jobId: number;
  email: string;
  name: string;
  role: string;
  experience: string;
  skills: string[];
  education: string;
  previousCompany: string;
  salary: string;
  summary: string;
  score: number | null;
  recommendation: string | null;
  strengths: string[];
  concerns: string[];
  salaryFit: string | null;
  rank: number | null;
  interviewStatus: "Pending" | "Invited" | "Completed";
  interviewToken: string | null;
  aiInterviewScore: number | null;
  aiInterviewFeedback: string | null;
}

export default function RecruitmentPage() {
  const router = useRouter();
  const [jobs, setJobs] = useState<Job[]>([]);
  const [selectedJobId, setSelectedJobId] = useState<number | null>(null);
  const [resumes, setResumes] = useState<Candidate[]>([]);
  
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [actionLoadingId, setActionLoadingId] = useState<number | null>(null);
  const [error, setError] = useState("");

  const [isCreatingJob, setIsCreatingJob] = useState(false);
  const [newRole, setNewRole] = useState("");
  const [newMustHave, setNewMustHave] = useState("");
  const [newNiceToHave, setNewNiceToHave] = useState("");
  const [newBudget, setNewBudget] = useState("");

  const [isEditingJob, setIsEditingJob] = useState(false);
  const [editRole, setEditRole] = useState("");
  const [editMustHave, setEditMustHave] = useState("");
  const [editNiceToHave, setEditNiceToHave] = useState("");
  const [editBudget, setEditBudget] = useState("");

  const safeResumes = Array.isArray(resumes) ? resumes : [];

  useEffect(() => {
    fetchJobs();
  }, []);

  useEffect(() => {
    if (selectedJobId !== null) {
      fetchCandidates(selectedJobId);
      setIsEditingJob(false);
    } else {
      setResumes([]);
    }
  }, [selectedJobId]);

  const currentJob = jobs.find(j => j.id === selectedJobId);
  
  useEffect(() => {
    if (currentJob) {
      setEditRole(currentJob.role);
      setEditMustHave(currentJob.mustHave ? currentJob.mustHave.join(", ") : "");
      setEditNiceToHave(currentJob.niceToHave ? currentJob.niceToHave.join(", ") : "");
      setEditBudget(currentJob.budgetMax);
    }
  }, [currentJob, isEditingJob]);

  const fetchJobs = async () => {
    try {
      const res = await fetch("https://hrms-ai-5.onrender.com/jobs");
      const data = await res.json();
      setJobs(Array.isArray(data) ? data : []);
      if (data.length > 0 && !selectedJobId) {
        setSelectedJobId(data[0].id);
      }
    } catch (e) {
      setError("Failed loading persistent configurations from SQLite database.");
    }
  };

  const fetchCandidates = async (jobId: number) => {
    try {
      const res = await fetch(`https://hrms-ai-5.onrender.com/jobs/${jobId}/candidates`);
      const data = await res.json();
      setResumes(Array.isArray(data) ? data : data ? [data] : []);
    } catch (e) {
      setError("Failed running network sync operations.");
    }
  };

  const handleCreateJob = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("https://hrms-ai-5.onrender.com/jobs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          role: newRole,
          mustHave: newMustHave.split(",").map(s => s.trim()).filter(s => s !== ""),
          niceToHave: newNiceToHave.split(",").map(s => s.trim()).filter(s => s !== ""),
          budgetMax: newBudget
        })
      });
      const dynamicJob = await res.json();
      setJobs(prev => [...prev, dynamicJob]);
      setSelectedJobId(dynamicJob.id);
      setIsCreatingJob(false);
      setNewRole(""); setNewMustHave(""); setNewNiceToHave(""); setNewBudget("");
    } catch (err) {
      setError("Could not register job position entity.");
    }
  };

  const handleUpdateJobRequirements = async (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedJobId === null) return;
    setError("");

    try {
      const res = await fetch(`https://hrms-ai-5.onrender.com/jobs/${selectedJobId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          role: editRole,
          mustHave: editMustHave.split(",").map(s => s.trim()).filter(s => s !== ""),
          niceToHave: editNiceToHave.split(",").map(s => s.trim()).filter(s => s !== ""),
          budgetMax: editBudget
        })
      });
      
      if (!res.ok) throw new Error("Backend synchronization rejected.");
      const updatedJob = await res.json();
      
      setJobs(prev => prev.map(j => j.id === selectedJobId ? updatedJob : j));
      setIsEditingJob(false);
    } catch (err) {
      setError("Could not persist changes to the target profile matrix.");
    }
  };

  const handleDeleteJob = async () => {
    if (selectedJobId === null) return;
    if (!confirm("Are you sure you want to completely delete this job opening and all its candidates?")) return;
    setError("");

    try {
      const res = await fetch(`https://hrms-ai-5.onrender.com/jobs/${selectedJobId}`, {
        method: "DELETE"
      });

      if (!res.ok) throw new Error("Backend failed to process row removal.");

      const remainingJobs = jobs.filter(j => j.id !== selectedJobId);
      setJobs(remainingJobs);

      if (remainingJobs.length > 0) {
        setSelectedJobId(remainingJobs[0].id);
      } else {
        setSelectedJobId(null);
        setResumes([]);
      }
      setIsEditingJob(false);
    } catch (err) {
      setError("Could not safely wipe target position record row.");
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || selectedJobId === null) return;

    setUploading(true);
    setError("");

    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("jobId", selectedJobId.toString());

      const response = await fetch("https://hrms-ai-5.onrender.com/extract-resume", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) throw new Error("Processing failed.");
      const freshCandidate = await response.json();
      setResumes(prev => [freshCandidate, ...(Array.isArray(prev) ? prev : [])]);
    } catch (err: any) {
      setError("Connection breakdown. Verify that document text can be parsed.");
    } finally {
      setUploading(false);
      e.target.value = "";
    }
  };

  const screenResumes = async () => {
    if (safeResumes.length === 0 || selectedJobId === null) return;
    loading || setLoading(true);
    setError("");

    try {
      const response = await fetch("https://hrms-ai-5.onrender.com/resume-analysis", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ jobId: selectedJobId }),
      });

      if (!response.ok) throw new Error("Server error during screening.");
      const updatedCandidates = await response.json();
      
      if (Array.isArray(updatedCandidates) && updatedCandidates.length > 0) {
        setResumes(updatedCandidates);
      } else {
        fetchCandidates(selectedJobId);
      }
    } catch (e) {
      setError("Failed to compile evaluation matrix profile data context.");
    } finally {
      setLoading(false);
    }
  };

  const handleAcceptAndInvite = async (candidateId: number) => {
    setActionLoadingId(candidateId);
    setError("");
    try {
      const response = await fetch(`https://hrms-ai-5.onrender.com/candidates/${candidateId}/accept`, {
        method: "POST"
      });
      if (!response.ok) throw new Error("Failed to advance candidate status context.");
      
      const data = await response.json();
      setResumes(prev => (Array.isArray(prev) ? prev : []).map(cand => cand.id === candidateId ? data.candidate : cand));
      alert(`Success! Email containing automated dynamic interview links dispatched out to: ${data.candidate.email}`);
    } catch (err: any) {
      setError(err.message || "Could not dispatch AI environment token invitation.");
    } finally {
      setActionLoadingId(null);
    }
  };

  const recColor: Record<string, string> = {
    "Strong Hire": "text-green-400 bg-green-400/10 border-green-400/20",
    "Hire": "text-blue-400 bg-blue-400/10 border-blue-400/20",
    "Maybe": "text-yellow-400 bg-yellow-400/10 border-yellow-400/20",
    "Reject": "text-red-400 bg-red-400/10 border-red-400/20",
  };

  return (
    <div className="min-h-screen bg-[#0a0f1e] text-white p-4 sm:p-6 md:p-8 w-full">
      
      {/* 🔙 Minimalist Back Navigation Trigger */}
      <button 
        onClick={() => router.push("/dashboard")}
        className="text-xs text-gray-400 hover:text-blue-400 flex items-center gap-1.5 transition-colors"
      >
        ← Back to Command Center
      </button>

      {/* Top Controller Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-white/10 pb-6 gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight">AI Recruitment Pipeline</h1>
          <p className="text-gray-500 text-xs mt-1">Persistent Storage Active via SQLite Models</p>
        </div>
        
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full sm:w-auto">
          <div className="relative w-full sm:w-64">
            <select 
              value={selectedJobId || ""} 
              onChange={(e) => setSelectedJobId(Number(e.target.value))}
              className="w-full bg-[#111827] border border-white/10 text-sm rounded-xl px-4 py-2.5 focus:outline-none focus:border-blue-500 text-white appearance-none cursor-pointer"
            >
              {jobs.map(j => <option key={j.id} value={j.id} className="text-white">{j.role} (ID: {j.id})</option>)}
            </select>
            <div className="absolute inset-y-0 right-4 flex items-center pointer-events-none text-gray-500 text-xs">▼</div>
          </div>
          <button 
            onClick={() => {
              setIsCreatingJob(!isCreatingJob);
              setIsEditingJob(false);
            }}
            className="bg-blue-500 hover:bg-blue-600 px-4 py-2.5 rounded-xl text-sm font-medium transition-all text-center shrink-0 shadow-lg shadow-blue-500/10 active:scale-95"
          >
            {isCreatingJob ? "Close Creator" : "➕ Create New Job"}
          </button>
        </div>
      </div>

      {error && <div className="bg-red-500/10 border border-red-500/20 text-red-400 text-sm p-4 rounded-xl">{error}</div>}

      {/* Conditional Job Entry Form */}
      {isCreatingJob && (
        <form onSubmit={handleCreateJob} className="bg-[#111827] border border-white/10 rounded-2xl p-5 md:p-6 space-y-4">
          <h3 className="font-semibold text-sm border-b border-white/5 pb-2">Add Structural Database Job Target</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs text-gray-400 font-medium pl-0.5">Job Title</label>
              <input type="text" placeholder="e.g., Software Engineer" value={newRole} onChange={e=>setNewRole(e.target.value)} className="w-full bg-[#0a0f1e] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500" required />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs text-gray-400 font-medium pl-0.5">Salary Cap</label>
              <input type="text" placeholder="e.g., 18 LPA" value={newBudget} onChange={e=>setNewBudget(e.target.value)} className="w-full bg-[#0a0f1e] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500" required />
            </div>
          </div>
          <div className="space-y-1.5">
            <label className="text-xs text-gray-400 font-medium pl-0.5">Must Have Skills (comma separated)</label>
            <input type="text" placeholder="e.g., Java, React, SQL" value={newMustHave} onChange={e=>setNewMustHave(e.target.value)} className="w-full bg-[#0a0f1e] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500" required />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs text-gray-400 font-medium pl-0.5">Nice to Have Skills (comma separated)</label>
            <input type="text" placeholder="e.g., AWS, Docker" value={newNiceToHave} onChange={e=>setNewNiceToHave(e.target.value)} className="w-full bg-[#0a0f1e] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500" />
          </div>
          <div className="flex justify-end pt-2">
            <button type="submit" className="w-full sm:w-auto bg-green-500 hover:bg-green-600 text-white font-medium text-xs tracking-wide uppercase px-5 py-3 rounded-xl transition-all shadow-lg shadow-green-500/10 active:scale-95">Commit Position to SQLite</button>
          </div>
        </form>
      )}

      {/* Core Display Blocks */}
      {currentJob ? (
        <>
          {/* Criteria Target Panel Box */}
          <div className="bg-[#111827] border border-white/10 rounded-2xl p-5 md:p-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4 border-b border-white/5 pb-4 gap-3">
              <div>
                <span className="text-[10px] tracking-wider uppercase text-gray-500 font-bold block mb-0.5">Target Open Position Profile</span>
                <h2 className="text-white font-semibold text-lg capitalize">{currentJob.role}</h2>
              </div>
              <div className="flex items-center gap-2 self-start sm:self-center">
                <button
                  onClick={() => {
                    setIsEditingJob(!isEditingJob);
                    setIsCreatingJob(false);
                  }}
                  className="text-xs text-blue-400 bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/20 px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1"
                >
                  ✏️ {isEditingJob ? "Cancel" : "Edit Criteria"}
                </button>
                <button
                  type="button"
                  onClick={handleDeleteJob}
                  className="text-xs text-red-400 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1"
                >
                  🗑️ Delete
                </button>
              </div>
            </div>

            {isEditingJob ? (
              <form onSubmit={handleUpdateJobRequirements} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="block text-gray-400 text-xs pl-0.5">Position / Role Title</label>
                    <input
                      type="text"
                      value={editRole}
                      onChange={(e) => setEditRole(e.target.value)}
                      className="w-full bg-[#0a0f1e] border border-white/10 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-blue-500"
                      required
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="block text-gray-400 text-xs pl-0.5">Budget Max</label>
                    <input
                      type="text"
                      value={editBudget}
                      onChange={(e) => setEditBudget(e.target.value)}
                      className="w-full bg-[#0a0f1e] border border-white/10 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-blue-500"
                      required
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <label className="block text-gray-400 text-xs pl-0.5">Must-Have Skills (Comma-separated)</label>
                  <input
                    type="text"
                    value={editMustHave}
                    onChange={(e) => setEditMustHave(e.target.value)}
                    className="w-full bg-[#0a0f1e] border border-white/10 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="block text-gray-400 text-xs pl-0.5">Nice-to-Have Skills (Comma-separated)</label>
                  <input
                    type="text"
                    value={editNiceToHave}
                    onChange={(e) => setEditNiceToHave(e.target.value)}
                    className="w-full bg-[#0a0f1e] border border-white/10 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div className="flex justify-end pt-2">
                  <button
                    type="submit"
                    className="w-full sm:w-auto bg-blue-500 hover:bg-blue-600 text-white text-xs font-medium px-5 py-3 rounded-xl transition-all shadow-lg shadow-blue-500/10 active:scale-95"
                  >
                    Save Requirements Matrix
                  </button>
                </div>
              </form>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-2">
                <div>
                  <div className="text-gray-500 text-[11px] uppercase tracking-wider mb-1">Target Profile</div>
                  <div className="font-semibold text-sm text-white capitalize">{currentJob.role}</div>
                </div>
                <div>
                  <div className="text-gray-500 text-[11px] uppercase tracking-wider mb-1">Must Have Skills</div>
                  <div className="flex flex-wrap gap-1.5">
                    {(currentJob.mustHave || []).map(s => (
                      <span key={s} className="bg-blue-500/10 text-blue-400 border border-blue-500/15 text-xs px-2.5 py-0.5 rounded font-mono font-medium">{s}</span>
                    ))}
                  </div>
                </div>
                <div>
                  <div className="text-gray-500 text-[11px] uppercase tracking-wider mb-1">Hiring Budget</div>
                  <div className="font-semibold text-sm text-white tracking-wide">{currentJob.budgetMax}</div>
                </div>
              </div>
            )}
          </div>

          {/* Upload Dropzone */}
          <div className="border-2 border-dashed border-white/10 hover:border-blue-500/40 bg-[#111827]/50 hover:bg-[#111827] rounded-2xl p-6 md:p-8 text-center relative transition-all cursor-pointer group">
            <input type="file" accept=".pdf,.docx,.txt" onChange={handleFileUpload} className="absolute inset-0 opacity-0 cursor-pointer z-10" disabled={uploading || loading} />
            <div className="max-w-xs mx-auto space-y-3">
              <span className="text-3xl block group-hover:scale-110 transition-transform duration-200">{uploading ? "⏳" : "📁"}</span>
              <div>
                <p className="text-sm font-medium">{uploading ? "Extracting profile text content securely..." : `Upload Candidate for ${currentJob.role}`}</p>
                <p className="text-gray-500 text-xs mt-1">Drag and drop PDF resumes or click to browse local files</p>
              </div>
            </div>
          </div>

          {/* Corrected Queue List Layout Panel */}
          <div className="bg-[#111827] border border-white/10 rounded-2xl p-5 md:p-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 mb-4 border-b border-white/5 gap-4">
              <div>
                <h2 className="font-semibold text-base">Base Registrations Saved</h2>
                <p className="text-xs text-gray-500 mt-0.5">
                  {safeResumes.filter(r => r.score === null || r.score === undefined).length} pending screening
                </p>
              </div>
              {safeResumes.length > 0 && (
                <button 
                  onClick={screenResumes} 
                  disabled={loading} 
                  className="w-full sm:w-auto bg-blue-500 hover:bg-blue-600 px-5 py-3 rounded-xl text-xs uppercase tracking-wide font-medium disabled:opacity-50 transition-all shadow-lg shadow-blue-500/10 active:scale-95 text-center"
                >
                  {loading ? "🤖 Syncing Evaluations..." : "🎯 Run Pipeline Evaluation"}
                </button>
              )}
            </div>

            {loading && (
              <div className="text-center py-8">
                <div className="text-2xl mb-2 animate-bounce">📊</div>
                <div className="text-white text-sm font-medium">Cross-referencing experience benchmarks...</div>
              </div>
            )}

            <div className="space-y-3">
              {safeResumes.filter(r => r.score === null || r.score === undefined).map(r => (
                <div key={r.id} className="p-4 bg-white/[0.01] border border-white/5 rounded-xl flex flex-col gap-2">
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-1">
                    <div>
                      <div className="text-sm font-bold text-white">{r.name} <span className="text-gray-500 font-normal text-xs ml-1">({r.email})</span></div>
                      <div className="text-xs text-blue-400 mt-0.5">{r.role || "Not Listed"}</div>
                    </div>
                    <div className="text-left sm:text-right text-xs text-gray-400 font-medium">
                      Exp: <span className="text-gray-300 font-semibold">{r.experience || "N/A"}</span> | Salary: <span className="text-gray-300 font-semibold">{r.salary || "N/A"}</span>
                    </div>
                  </div>
                  {r.summary && <p className="text-xs text-gray-400 bg-black/20 p-2.5 rounded-lg border border-white/5 italic">"{r.summary}"</p>}
                  <div className="flex gap-1.5 flex-wrap pt-0.5">
                    {(r.skills || []).map(s => (
                      <span key={s} className="bg-blue-500/5 border border-blue-500/10 text-blue-400 text-[10px] px-2.5 py-0.5 rounded font-mono font-medium">{s}</span>
                    ))}
                  </div>
                </div>
              ))}
              
              {safeResumes.filter(r => r.score === null || r.score === undefined).length === 0 && !loading && (
                <p className="text-xs text-gray-500 text-center py-6">No pending candidates. Drag a file above to add them to the system database.</p>
              )}
            </div>
          </div>

          {/* Score Evaluation Matrix Block */}
          {safeResumes.filter(r => r.score !== null && r.score !== undefined).length > 0 && (
            <div className="space-y-4">
              <h2 className="font-semibold text-base pl-0.5">Persistent Rank Presentation Outputs</h2>
              <div className="space-y-4">
                {safeResumes
                  .filter(r => r.score !== null && r.score !== undefined)
                  .sort((a, b) => Number(a.rank || 0) - Number(b.rank || 0))
                  .map((res) => (
                    <div key={res.id} className="bg-[#111827] border border-white/10 rounded-2xl p-5 md:p-6 space-y-4">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
                        <div className="flex items-center gap-3">
                          <div className="bg-blue-500 w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs text-white shrink-0 shadow-md shadow-blue-500/20">#{res.rank || "-"}</div>
                          <div>
                            <h4 className="font-bold text-sm text-white">{res.name}</h4>
                            <p className="text-xs text-gray-500 mt-0.5">{res.role}</p>
                          </div>
                        </div>
                        <div className="flex items-center justify-between sm:justify-end gap-4 w-full sm:w-auto">
                          <span className={`text-[11px] px-3 py-1 rounded-full border font-medium tracking-wide ${recColor[res.recommendation || ""] || "text-gray-400"}`}>{res.recommendation || "Pending"}</span>
                          <div className="text-right flex items-baseline gap-0.5 shrink-0">
                            <span className="font-bold text-lg text-white tracking-tight">{res.score}</span>
                            <span className="text-[10px] text-gray-500 font-medium">/100</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                        <div className="space-y-1.5">
                          <div className="text-gray-500 font-bold tracking-wider text-[10px]">STRENGTHS</div>
                          <div className="space-y-1">
                            {(res.strengths || []).map(s=><div key={s} className="text-green-400 font-medium flex items-center gap-1">✓ <span className="text-gray-300">{s}</span></div>)}
                          </div>
                        </div>
                        <div className="space-y-1.5">
                          <div className="text-gray-500 font-bold tracking-wider text-[10px]">CONCERNS</div>
                          <div className="space-y-1">
                            {res.concerns && res.concerns.length > 0 ? res.concerns.map(c=><div key={c} className="text-red-400 font-medium flex items-start gap-1">✗ <span className="text-gray-300">{c}</span></div>) : <div className="text-gray-600">None</div>}
                          </div>
                        </div>
                        <div className="space-y-1.5">
                          <div className="text-gray-500 font-bold tracking-wider text-[10px]">BUDGET CHECK</div>
                          <div className="text-white font-medium bg-white/[0.02] border border-white/5 rounded-xl p-2.5 inline-block w-full sm:w-auto text-center sm:text-left">
                            {res.salaryFit || "N/A"}
                          </div>
                        </div>
                      </div>

                      <div className="border-t border-white/5 pt-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div>
                          <div className="text-[10px] text-gray-500 font-bold tracking-wider">AI CHAT BOT SCREENING STAGE</div>
                          <div className="flex items-center gap-2 mt-1">
                            <span className={`inline-block w-2 h-2 rounded-full ${
                              res.interviewStatus === "Completed" ? "bg-green-400 animate-pulse" : res.interviewStatus === "Invited" ? "bg-yellow-400 animate-pulse" : "bg-gray-500"
                            }`} />
                            <span className="text-xs font-semibold capitalize text-gray-300">{res.interviewStatus || "Pending"}</span>
                          </div>
                        </div>
                        <div className="w-full md:w-auto">
                          {(!res.interviewStatus || res.interviewStatus === "Pending") && (
                            <button
                              onClick={() => handleAcceptAndInvite(res.id)}
                              disabled={actionLoadingId === res.id}
                              className="w-full md:w-auto bg-emerald-600 hover:bg-emerald-700 text-white font-medium text-xs uppercase tracking-wider px-4 py-2.5 rounded-xl transition-all disabled:opacity-40 text-center shadow-lg shadow-emerald-600/10"
                            >
                              {actionLoadingId === res.id ? "Processing Approval..." : "✅ Accept & Invite"}
                            </button>
                          )}
                          {res.interviewStatus === "Invited" && (
                            <div className="text-xs text-yellow-400/90 bg-yellow-400/5 border border-yellow-400/10 rounded-xl px-4 py-2.5 italic text-center md:text-right">
                              Waiting for candidate to initiate secure link...
                            </div>
                          )}
                          {res.interviewStatus === "Completed" && (
                            <div className="text-left md:text-right">
                              <div className="text-[10px] text-gray-500 font-bold tracking-wider">INTERACTIVE RATING SCORE</div>
                              <span className="text-sm font-bold text-emerald-400 mt-0.5 block">{res.aiInterviewScore} / 100</span>
                            </div>
                          )}
                        </div>
                      </div>

                      {res.interviewStatus === "Completed" && res.aiInterviewFeedback && (
                        <div className="bg-black/20 rounded-xl p-4 border border-white/5">
                          <div className="text-[10px] font-bold text-blue-400 tracking-wider uppercase mb-1.5">AI Live Interaction Synthesis Report</div>
                          <p className="text-xs text-gray-300 whitespace-pre-wrap committees-text leading-relaxed font-normal">{res.aiInterviewFeedback}</p>
                        </div>
                      )}
                    </div>
                  ))}
              </div>
            </div>
          )}
        </>
      ) : (
        <div className="text-center py-12 bg-[#111827] border border-white/10 rounded-2xl">
          <p className="text-gray-400 text-sm">No job openings found. Click "➕ Create New Job" above to get started.</p>
        </div>
      )}
    </div>
  );
}