"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";

interface Employee {
  id: number;
  name?: string;
  department?: string;
  role?: string;
  email?: string;
  salary?: string;
  experience?: string;
  skills?: string;
  status?: string;
}

const departments = ["Engineering", "Sales", "Marketing", "HR", "Finance", "Operations"];
const statusOptions = ["Active", "On Leave", "Probation"];

export default function EmployeesPage() {
  const router = useRouter();
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [search, setSearch] = useState("");
  const [filterDept, setFilterDept] = useState("All");
  const [selectedEmp, setSelectedEmp] = useState<Employee | null>(null);

  const [form, setForm] = useState({
    name: "",
    department: "Engineering",
    role: "",
    email: "",
    salary: "",
    experience: "",
    skills: "",
    status: "Active",
  });

  const fetchEmployees = async () => {
    try {
      setError("");
      const res = await fetch("https://hrms-ai-5.onrender.com/employees");
      if (!res.ok) throw new Error(`HTTP network error code: ${res.status}`);
      const data = await res.json();
      setEmployees(Array.isArray(data) ? data : []);
    } catch (e: any) {
      setError("Cannot sync with Flask database repository.");
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEmployees();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.role || !form.email) {
      setError("Name, Role and Email parameters are required.");
      return;
    }

    try {
      const res = await fetch("https://hrms-ai-5.onrender.com/employees", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error("Pushed transaction was rejected.");
      setSuccess("Employee entry logged successfully!");
      setShowForm(false);
      setForm({ name: "", department: "Engineering", role: "", email: "", salary: "", experience: "", skills: "", status: "Active" });
      fetchEmployees();
      setTimeout(() => setSuccess(""), 3000);
    } catch (e) {
      setError("Failed to append candidate entry downstream.");
    }
  };

  const handleDelete = async (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm("Are you sure you want to delete this employee profile?")) return;
    try {
      const res = await fetch(`https://hrms-ai-5.onrender.com/employees/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Deletion rejected by database.");
      if (selectedEmp?.id === id) setSelectedEmp(null);
      fetchEmployees();
    } catch (e) {
      setError("Failed to execute data removal process.");
    }
  };

  const filtered = employees.filter((e) => {
    const empName = e?.name?.toLowerCase() || "";
    const empRole = e?.role?.toLowerCase() || "";
    const empDept = e?.department || "Engineering";

    const matchSearch = empName.includes(search.toLowerCase()) || empRole.includes(search.toLowerCase());
    const matchDept = filterDept === "All" || empDept === filterDept;
    return matchSearch && matchDept;
  });

  return (
    <div className="min-h-screen bg-[#070b16] text-slate-100 antialiased selection:bg-blue-500/30 pb-12">
      
      {/* 📱💻 Responsive Header */}
      <header className="border-b border-white/[0.06] bg-[#090f20]/80 backdrop-blur-md px-4 md:px-8 py-4 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-2 md:gap-4">
          <button 
            onClick={() => router.push("/dashboard")} 
            className="text-slate-400 hover:text-white text-xs md:text-sm font-medium transition-all duration-200 flex items-center gap-1 group"
          >
            ← <span className="hidden sm:inline">Back</span>
          </button>
          <div className="h-4 w-[1px] bg-white/10" />
          <div>
            <h1 className="text-white font-semibold text-sm md:text-lg tracking-tight">Employees</h1>
            <p className="text-slate-400 text-[10px] md:text-xs mt-0.5 hidden xs:block">Workforce Directory Mapping</p>
          </div>
        </div>
        <button
          onClick={() => { setShowForm(!showForm); setSelectedEmp(null); setError(""); }}
          className="bg-blue-500 hover:bg-blue-600 text-white text-[11px] md:text-xs font-semibold tracking-wide uppercase px-3 py-2 md:px-5 md:py-2.5 rounded-lg transition-all shadow-lg shadow-blue-500/10"
        >
          {showForm ? "✕ Close" : "+ Add Member"}
        </button>
      </header>

      <main className="max-w-[1600px] mx-auto p-4 md:p-8 space-y-6">
        {success && <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-lg p-3 md:p-4 text-emerald-400 text-xs md:text-sm animate-fadeIn">✓ {success}</div>}
        {error && <div className="bg-rose-500/10 border border-rose-500/20 rounded-lg p-3 md:p-4 text-rose-400 text-xs md:text-sm animate-fadeIn">⚠️ {error}</div>}

        {/* 📉 Quick Metrics Cards Row */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-5">
          {[
            { label: "Total Workforce", value: employees.length },
            { label: "Active Staff", value: employees.filter(e => e?.status === "Active" || !e?.status).length },
            { label: "On Leave", value: employees.filter(e => e?.status === "On Leave").length },
            { label: "Departments", value: [...new Set(employees.map(e => e?.department || "Engineering"))].length },
          ].map((s, index) => (
            <div key={index} className="bg-[#0d1527] border border-white/[0.06] rounded-xl p-3 md:p-5 shadow-xl">
              <div className="text-slate-400 text-[9px] md:text-[10px] font-bold uppercase tracking-wider">{s.label}</div>
              <div className="text-white text-xl md:text-2xl font-bold tracking-tight mt-1 md:mt-2.5">{s.value}</div>
            </div>
          ))}
        </div>

        {/* 🔍 Dynamic Filters Panel */}
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search name or operational role tag..."
            className="flex-1 bg-[#0d1527] border border-white/[0.06] rounded-lg px-4 py-2.5 text-white text-sm outline-none focus:border-blue-500 transition-colors"
          />
          <select 
            value={filterDept} 
            onChange={(e) => setFilterDept(e.target.value)} 
            className="bg-[#0d1527] border border-white/[0.06] rounded-lg px-4 py-2.5 text-white text-sm outline-none focus:border-blue-500 cursor-pointer"
          >
            <option value="All" className="bg-[#0d1527]">All Departments</option>
            {departments.map((d) => <option key={d} value={d} className="bg-[#0d1527]">{d}</option>)}
          </select>
        </div>

        {/* 🗃️ Primary Workspace Split Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* Main List Workspace Area */}
          <div className={`bg-[#0d1527] border border-white/[0.06] rounded-xl shadow-2xl overflow-hidden transition-all duration-300 ${selectedEmp ? "lg:col-span-7" : "lg:col-span-12"}`}>
            {loading ? (
              <div className="text-center py-16 text-slate-400 text-xs flex flex-col items-center gap-3">
                <span className="w-5 h-5 border-2 border-white/20 border-t-blue-500 rounded-full animate-spin" />
                Synchronizing Database Logs...
              </div>
            ) : filtered.length === 0 ? (
              <div className="text-center py-16 text-slate-400 text-sm">No data logs matched parameters.</div>
            ) : (
              <>
                {/* 💻 Desktop View: Table Hidden on Small Viewports */}
                <div className="hidden md:block overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-white/[0.06] bg-[#111b33]/30 text-[10px] uppercase font-bold tracking-wider text-slate-400">
                        <th className="px-6 py-4">Employee Identity</th>
                        <th className="px-4 py-4">Department Structure</th>
                        <th className="px-4 py-4">Compensation</th>
                        <th className="px-4 py-4">Status</th>
                        <th className="px-4 py-4 text-right pr-6">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/[0.04]">
                      {filtered.map((emp, i) => {
                        const isRowSelected = selectedEmp?.id === emp.id;
                        return (
                          <tr 
                            key={emp.id || i} 
                            onClick={() => setSelectedEmp(emp)} 
                            className={`group cursor-pointer transition-all duration-150 ${isRowSelected ? "bg-blue-500/[0.06] border-l-4 border-blue-500" : "hover:bg-white/[0.02]"}`}
                          >
                            <td className="px-6 py-3.5">
                              <div className="flex items-center gap-3">
                                <div className={`w-8 h-8 rounded-md flex items-center justify-center text-xs font-bold border ${isRowSelected ? "bg-blue-500/20 border-blue-400 text-blue-400" : "bg-slate-800 border-white/10 text-slate-300"}`}>{emp?.name ? emp.name.charAt(0) : "E"}</div>
                                <div>
                                  <div className="text-sm font-medium tracking-tight text-white group-hover:text-blue-400 transition-colors">{emp?.name || "Unnamed Node"}</div>
                                  <div className="text-slate-500 text-xs mt-0.5">{emp?.email}</div>
                                </div>
                              </div>
                            </td>
                            <td className="px-4 py-3.5">
                              <div className="text-slate-300 text-sm font-medium">{emp?.department || "Engineering"}</div>
                              <div className="text-slate-500 text-xs mt-0.5">{emp?.role}</div>
                            </td>
                            <td className="px-4 py-3.5 text-slate-300 text-sm font-mono">{emp?.salary || "—"}</td>
                            <td className="px-4 py-3.5">
                              <span className={`text-[10px] uppercase font-bold tracking-wider px-2.5 py-1 rounded-md border ${emp?.status === "Active" || !emp?.status ? "text-emerald-400 bg-emerald-500/10 border-emerald-500/20" : emp?.status === "On Leave" ? "text-amber-400 bg-amber-500/10 border-amber-500/20" : "text-blue-400 bg-blue-500/10 border-blue-500/20"}`}>
                                {emp?.status || "Active"}
                              </span>
                            </td>
                            <td className="px-4 py-3.5 text-right pr-6">
                              <button onClick={(e) => handleDelete(emp.id, e)} className="text-rose-400/70 hover:text-rose-400 text-xs px-2.5 py-1 rounded-md hover:bg-rose-500/10 transition-colors">Delete</button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                {/* 📱 Mobile UI: High-Density Card Feed View List */}
                <div className="block md:hidden divide-y divide-white/[0.06]">
                  {filtered.map((emp, i) => (
                    <div 
                      key={emp.id || i} 
                      onClick={() => setSelectedEmp(emp)}
                      className={`p-4 space-y-3 active:bg-white/[0.04] ${selectedEmp?.id === emp.id ? "bg-blue-500/[0.04]" : ""}`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-lg bg-slate-800 border border-white/10 flex items-center justify-center text-sm font-bold text-slate-300">{emp?.name ? emp.name.charAt(0) : "E"}</div>
                          <div>
                            <h4 className="text-white text-sm font-semibold">{emp?.name || "Unnamed Node"}</h4>
                            <p className="text-slate-400 text-xs">{emp?.role || "No Role Stated"}</p>
                          </div>
                        </div>
                        <span className={`text-[9px] uppercase font-bold tracking-wider px-2 py-0.5 rounded border ${emp?.status === "Active" || !emp?.status ? "text-emerald-400 bg-emerald-500/10 border-emerald-500/20" : "text-amber-400 bg-amber-500/10 border-amber-500/20"}`}>
                          {emp?.status || "Active"}
                        </span>
                      </div>

                      <div className="flex items-center justify-between text-xs pt-1">
                        <div className="text-slate-400">
                          <span className="text-slate-500">Dept:</span> {emp?.department || "Engineering"}
                        </div>
                        <div className="font-mono text-blue-400 font-medium">
                          {emp?.salary || "—"}
                        </div>
                      </div>

                      <div className="flex justify-between items-center pt-2 border-t border-white/[0.04]">
                        <span className="text-[11px] text-slate-500 truncate max-w-[180px]">{emp?.email}</span>
                        <button 
                          onClick={(e) => handleDelete(emp.id, e)} 
                          className="text-rose-400 text-xs px-2 py-1 bg-rose-500/10 rounded"
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>

          {/* 📄 Dynamic Details Side-Drawer View Profile */}
          {selectedEmp && (
            <div className="lg:col-span-5 bg-[#0d1527] border border-white/[0.06] rounded-xl p-5 md:p-6 shadow-2xl sticky lg:top-24 space-y-6 animate-fadeIn">
              <div className="flex items-start justify-between border-b border-white/[0.06] pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-500/10 border border-blue-500/30 text-blue-400 flex items-center justify-center font-bold text-base">{selectedEmp?.name ? selectedEmp.name.charAt(0) : "E"}</div>
                  <div>
                    <h3 className="text-white font-bold text-base md:text-lg tracking-tight">{selectedEmp?.name || "Unnamed"}</h3>
                    <p className="text-slate-400 text-xs mt-0.5 truncate max-w-[180px] sm:max-w-none">{selectedEmp?.email}</p>
                  </div>
                </div>
                <button onClick={() => setSelectedEmp(null)} className="text-slate-400 hover:text-white text-xs bg-white/[0.04] px-2 py-1 rounded-md">✕ Close</button>
              </div>

              <div className="grid grid-cols-2 gap-3 md:gap-4">
                <div className="bg-slate-900/60 border border-white/[0.04] rounded-xl p-3.5"><div className="text-slate-500 text-[9px] uppercase font-bold tracking-wider mb-1">Department</div><div className="text-white text-xs md:text-sm font-semibold">{selectedEmp?.department}</div></div>
                <div className="bg-slate-900/60 border border-white/[0.04] rounded-xl p-3.5"><div className="text-slate-500 text-[9px] uppercase font-bold tracking-wider mb-1">Corporate Role</div><div className="text-white text-xs md:text-sm font-semibold">{selectedEmp?.role}</div></div>
                <div className="bg-slate-900/60 border border-white/[0.04] rounded-xl p-3.5"><div className="text-slate-500 text-[9px] uppercase font-bold tracking-wider mb-1">Compensation</div><div className="text-blue-400 text-xs md:text-sm font-bold font-mono">{selectedEmp?.salary || "N/A"}</div></div>
                <div className="bg-slate-900/60 border border-white/[0.04] rounded-xl p-3.5"><div className="text-slate-500 text-[9px] uppercase font-bold tracking-wider mb-1">Experience</div><div className="text-slate-200 text-xs md:text-sm font-medium">{selectedEmp?.experience || "N/A"}</div></div>
              </div>

              <div className="space-y-2">
                <div className="text-slate-500 text-[10px] uppercase font-bold tracking-wider">Acquired Skillsets</div>
                <p className="text-xs bg-[#111b33]/40 p-3 rounded-xl border border-white/[0.04] leading-relaxed text-slate-300 font-mono">{selectedEmp?.skills || "No skills documented within system ledger."}</p>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* 📄 Slide-out Create Employee Modal Overlay Form for Mobile View Enhancement */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-lg bg-[#0d1527] h-full border-l border-white/[0.08] p-5 md:p-6 overflow-y-auto flex flex-col justify-between">
            <div className="space-y-6">
              <div className="flex items-center justify-between border-b border-white/[0.06] pb-4">
                <div>
                  <h3 className="text-white font-bold text-lg">Add Employee Node</h3>
                  <p className="text-slate-400 text-xs">Append target registry profile row</p>
                </div>
                <button onClick={() => setShowForm(false)} className="text-slate-400 hover:text-white text-xl p-2">✕</button>
              </div>

              <form id="employee-form" onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="text-slate-400 text-[10px] font-semibold uppercase tracking-wider mb-1 block">Full Name *</label>
                  <input type="text" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full bg-[#111b33]/60 border border-white/[0.08] rounded-lg px-4 py-2 text-white text-sm outline-none focus:border-blue-500" placeholder="Rahul Sharma" />
                </div>
                <div>
                  <label className="text-slate-400 text-[10px] font-semibold uppercase tracking-wider mb-1 block">Email *</label>
                  <input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full bg-[#111b33]/60 border border-white/[0.08] rounded-lg px-4 py-2 text-white text-sm outline-none focus:border-blue-500" placeholder="rahul@company.com" />
                </div>
                <div>
                  <label className="text-slate-400 text-[10px] font-semibold uppercase tracking-wider mb-1 block">Role *</label>
                  <input type="text" required value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} className="w-full bg-[#111b33]/60 border border-white/[0.08] rounded-lg px-4 py-2 text-white text-sm outline-none focus:border-blue-500" placeholder="Senior Developer" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-slate-400 text-[10px] font-semibold uppercase tracking-wider mb-1 block">Department</label>
                    <select value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })} className="w-full bg-[#111b33]/60 border border-white/[0.08] rounded-lg px-3 py-2 text-white text-sm outline-none focus:border-blue-500">
                      {departments.map((d) => <option key={d} value={d} className="bg-[#0d1527]">{d}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-slate-400 text-[10px] font-semibold uppercase tracking-wider mb-1 block">Status</label>
                    <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })} className="w-full bg-[#111b33]/60 border border-white/[0.08] rounded-lg px-3 py-2 text-white text-sm outline-none focus:border-blue-500">
                      {statusOptions.map((s) => <option key={s} value={s} className="bg-[#0d1527]">{s}</option>)}
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-slate-400 text-[10px] font-semibold uppercase tracking-wider mb-1 block">Salary</label>
                    <input type="text" value={form.salary} onChange={(e) => setForm({ ...form, salary: e.target.value })} className="w-full bg-[#111b33]/60 border border-white/[0.08] rounded-lg px-4 py-2 text-white text-sm outline-none focus:border-blue-500" placeholder="12 LPA" />
                  </div>
                  <div>
                    <label className="text-slate-400 text-[10px] font-semibold uppercase tracking-wider mb-1 block">Experience</label>
                    <input type="text" value={form.experience} onChange={(e) => setForm({ ...form, experience: e.target.value })} className="w-full bg-[#111b33]/60 border border-white/[0.08] rounded-lg px-4 py-2 text-white text-sm outline-none focus:border-blue-500" placeholder="3 years" />
                  </div>
                </div>
                <div>
                  <label className="text-slate-400 text-[10px] font-semibold uppercase tracking-wider mb-1 block">Skills Set</label>
                  <input type="text" value={form.skills} onChange={(e) => setForm({ ...form, skills: e.target.value })} className="w-full bg-[#111b33]/60 border border-white/[0.08] rounded-lg px-4 py-2 text-white text-sm outline-none focus:border-blue-500" placeholder="React, Python, Java" />
                </div>
              </form>
            </div>

            <div className="border-t border-white/[0.06] pt-4 mt-6 flex gap-3">
              <button onClick={() => setShowForm(false)} className="flex-1 bg-white/5 hover:bg-white/10 text-slate-300 text-xs uppercase font-bold tracking-wider py-3 rounded-lg transition-colors">Cancel</button>
              <button form="employee-form" type="submit" className="flex-1 bg-blue-500 hover:bg-blue-600 text-white text-xs uppercase font-bold tracking-wider py-3 rounded-lg transition-colors shadow-lg shadow-blue-500/10">Commit Profile</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}