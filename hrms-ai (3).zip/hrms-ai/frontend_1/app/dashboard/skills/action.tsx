"use server";

export async function fetchGroqAnalysis(employeeData: any) {
  try {
    const groqApiKey = process.env.NEXT_PUBLIC_GROQ_API_KEY || process.env.GROQ_API_KEY;
    
    if (!groqApiKey) {
      throw new Error("GROQ API key is missing on the server environment.");
    }

    const prompt = `Analyze these real employee records for critical skill gaps based on their current roles and departments. 
    Return ONLY a raw JSON array matching this exact schema layout without any markdown block notation, backticks, or conversational filler words:
    [{"name": "Employee Name", "department": "Department", "missingSkills": ["Skill A", "Skill B"], "urgency": "High"}]

    Employee Dataset:
    ${JSON.stringify(employeeData)}`;

    const groqResponse = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${groqApiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "llama-3.3-70b-versatile",
        messages: [
          { role: "system", content: "You are an expert HR systems analyst that outputs ONLY raw JSON arrays without backticks or markdown formatting." },
          { role: "user", content: prompt }
        ],
        temperature: 0.1
      })
    });

    if (!groqResponse.ok) {
      const errText = await groqResponse.text();
      throw new Error(`Groq server returned status ${groqResponse.status}: ${errText}`);
    }

    const json = await groqResponse.json();
    
    if (json.choices && json.choices[0]?.message?.content) {
      let cleanText = json.choices[0].message.content.trim();
      cleanText = cleanText.replace(/```json|```/g, "").trim();
      return JSON.parse(cleanText);
    }
    
    throw new Error("Invalid structure returned from Groq API.");
  } catch (error: any) {
    console.error("Server Action Error:", error.message);
    throw error;
  }
}