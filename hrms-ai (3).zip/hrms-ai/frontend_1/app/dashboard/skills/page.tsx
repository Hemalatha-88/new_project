"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function SkillGapPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<any[]>([]);
  const [hasAudited, setHasAudited] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const analyzeSkills = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      // Direct call to your backend's live analysis route
      const res = await fetch("https://hrms-ai-5.onrender.com/api/analyze-skills", {
        method: "POST",
        headers: { "Content-Type": "application/json" }
      });
      
      if (!res.ok) {
        const body = await res.json();
        throw new Error(body.error || "Failed to process database records.");
      }

      const parsedAiData = await res.json();
      
      setResults(parsedAiData);
      setHasAudited(true);
    } catch (err: any) {
      console.error("Audit Runtime Error:", err.message);
      setErrorMsg(err.message || "Failed connecting to database API.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0f1e] text-white p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <button onClick={() => router.push("/dashboard")} className="mb-6 text-sm text-gray-400 hover:text-blue-400 transition-colors">
          ← Back to Dashboard
        </button>
        
        <div className="flex justify-between items-center bg-[#111827] border border-white/10 p-6 rounded-xl mb-8">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">🧠 Real-Time AI Skill Gap Analysis</h1>
            <p className="text-gray-400 text-sm mt-1">Live SQLite database rows passed directly into Groq analytical pipelines.</p>
          </div>
          <button 
            onClick={analyzeSkills} 
            disabled={loading}
            className={`px-6 py-2.5 rounded-lg text-sm font-medium transition-all ${
              loading ? "bg-blue-600/40 text-blue-200 cursor-not-allowed animate-pulse" : "bg-blue-600 hover:bg-blue-700 text-white"
            }`}
          >
            {loading ? "Analyzing Live Rows..." : "Run Real-Time Audit"}
          </button>
        </div>

        {errorMsg && (
          <div className="bg-red-500/10 border border-red-500/20 text-red-400 text-sm p-4 rounded-xl mb-6">
            ⚠️ <strong>Execution Blocked:</strong> {errorMsg} (Verify your Flask server is running on port 5000)
          </div>
        )}

        <div className="bg-[#111827] rounded-xl border border-white/10 overflow-hidden shadow-xl">
          {!hasAudited ? (
            <div className="text-center py-16 text-gray-500 text-sm">
              Ready for calculation. Click "Run Real-Time Audit" to extract live database positions.
            </div>
          ) : results.length === 0 ? (
            <div className="text-center py-16 text-gray-500 text-sm">
              Analysis returned no matching results. Check your database inputs.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-white/10 bg-white/[0.02] text-gray-400 text-xs tracking-wider uppercase">
                    <th className="px-6 py-4 font-medium">Employee Name</th>
                    <th className="px-6 py-4 font-medium">Department</th>
                    <th className="px-6 py-4 font-medium">Identified Gaps</th>
                    <th className="px-6 py-4 font-medium">Urgency Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {results.map((r, i) => (
                    <tr key={i} className="hover:bg-white/[0.01] transition-colors">
                      <td className="px-6 py-4 font-medium text-sm text-white">{r.name}</td>
                      <td className="px-6 py-4 text-gray-300 text-sm">{r.department}</td>
                      <td className="px-6 py-4">
                        <div className="flex flex-wrap gap-1.5">
                          {Array.isArray(r.missingSkills) ? (
                            r.missingSkills.map((skill: string, sIdx: number) => (
                              <span key={sIdx} className="bg-white/5 border border-white/10 text-gray-300 text-[11px] px-2 py-0.5 rounded-md">
                                {skill}
                              </span>
                            ))
                          ) : (
                            <span className="text-gray-400 text-sm">None Found</span>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`text-[11px] font-semibold px-2.5 py-0.5 rounded-full ${
                          r.urgency === "High" ? "text-red-400 bg-red-400/10" : 
                          r.urgency === "Medium" ? "text-yellow-400 bg-yellow-400/10" : "text-green-400 bg-green-400/10"
                        }`}>
                          {r.urgency || "Low"}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}