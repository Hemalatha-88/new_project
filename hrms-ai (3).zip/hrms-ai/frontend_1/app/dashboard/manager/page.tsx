"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";

interface Employee {
  id: number;
  name: string;
  department: string;
  role: string;
  email: string;
  salary: string;
  experience: string;
  skills: string;
  status: string;
}

interface ManagerResult {
  name: string;
  department: string;
  leadershipScore: number;
  riskLevel: string;
  strengths: string[];
  concerns: string[];
  recommendation: string;
  promotionReady: boolean;
  coachingNeeded: boolean;
}

export default function ManagerPage() {
  const router = useRouter();
  const [managers, setManagers] = useState<Employee[]>([]);
  const [fetching, setFetching] = useState(true);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<ManagerResult[]>([]);
  const [selected, setSelected] = useState<ManagerResult | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const res = await fetch("https://hrms-ai-5.onrender.com/employees");
        const data: Employee[] = await res.json();

        const managerList = data.filter((e) => {
          if (!e.role) return false;
          const role = e.role.toLowerCase();
          return (
            role.includes("manager") ||
            role.includes("lead") ||
            role.includes("head") ||
            role.includes("director") ||
            role === "senior"
          );
        });

        setManagers(managerList);
      } catch (e) {
        setError("Cannot connect to backend database repository. Verify Flask service.");
      } finally {
        setFetching(false);
      }
    };
    fetchEmployees();
  }, []);

  const analyzeManagers = async () => {
    if (managers.length === 0) {
      setError("No managers or leadership profiles found to evaluate.");
      return;
    }

    setLoading(true);
    setError("");
    setResults([]);

    try {
      const prompt = `You are an HR Leadership Intelligence AI.
Analyze these employees for leadership and management performance:

${managers.map((e, i) => `
Employee ${i + 1}: ${e.name}
- Department: ${e.department}
- Role: ${e.role}
- Experience: ${e.experience || "Not specified"}
- Salary: ${e.salary || "Not specified"}
- Skills: ${e.skills || "Not specified"}
- Status: ${e.status}
`).join("\n")}

For each person, evaluate their leadership potential and performance based on their role, experience and skills.
Return ONLY a JSON array with objects containing:
- name (string, must match exactly)
- department (string)
- leadershipScore (number 0-100)
- riskLevel (one of: "Low", "Medium", "High")
- strengths (array of 2-3 specific strengths based on their data)
- concerns (array of 1-2 specific concerns based on their data)
- recommendation (string: specific AI recommendation for this person)
- promotionReady (boolean: true if ready for promotion)
- coachingNeeded (boolean: true if they need coaching)

No markdown blocks, no formatting wrapper, output pure parsed JSON string array lines.`;

      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${process.env.NEXT_PUBLIC_GEMINI_API_KEY}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }],
            generationConfig: { temperature: 0.3 },
          }),
        }
      );

      const data = await response.json();
      const text = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
      const clean = text.replace(/```json|```/g, "").trim();
      const parsed: ManagerResult[] = JSON.parse(clean);
      parsed.sort((a, b) => b.leadershipScore - a.leadershipScore);
      setResults(parsed);
      setSelected(parsed[0]);
    } catch (e: any) {
      setError(e?.message || "Analysis configuration rejected by matrix ecosystem.");
    } finally {
      setLoading(false);
    }
  };

  const riskColor: Record<string, string> = {
    Low: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
    Medium: "text-amber-400 bg-amber-500/10 border-amber-500/20",
    High: "text-rose-400 bg-rose-500/10 border-rose-500/20",
  };

  const needCoaching = results.filter((r) => r.coachingNeeded).length;
  const promotionReadyCount = results.filter((r) => r.promotionReady).length;
  const avgScore = results.length > 0
    ? Math.round(results.reduce((a, b) => a + b.leadershipScore, 0) / results.length)
    : 0;

  return (
    <div className="min-h-screen bg-[#070b16] text-slate-100 antialiased pb-12">
      
      {/* 📱💻 Responsive Header Context */}
      <header className="border-b border-white/[0.06] bg-[#090f20]/80 backdrop-blur-md px-4 md:px-8 py-4 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-2 md:gap-4">
          <button 
            onClick={() => router.push("/dashboard")} 
            className="text-slate-400 hover:text-white text-xs md:text-sm font-medium transition-all duration-200 flex items-center gap-1"
          >
            ← <span className="hidden sm:inline">Back</span>
          </button>
          <div className="h-4 w-[1px] bg-white/10" />
          <div>
            <h1 className="text-white font-semibold text-sm md:text-lg tracking-tight">Manager Intelligence</h1>
            <p className="text-slate-400 text-[10px] md:text-xs mt-0.5">Leadership Audit Matrix</p>
          </div>
        </div>

        {!fetching && results.length === 0 && !loading && (
          <button
            onClick={analyzeManagers}
            disabled={loading || managers.length === 0}
            className="bg-blue-500 hover:bg-blue-600 disabled:opacity-40 text-white text-[11px] md:text-xs font-semibold tracking-wide uppercase px-3 py-2 md:px-5 md:py-2.5 rounded-lg transition-all shadow-lg shadow-blue-500/10"
          >
            🚀 Run AI Analysis
          </button>
        )}
      </header>

      <main className="max-w-[1500px] mx-auto p-4 md:p-8 space-y-6">
        
        {/* 📉 Adaptive Analytics High Density Scoring Stats Row */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-5">
          {[
            { label: "Tracked Leaders", value: results.length > 0 ? results.length : managers.length, color: "text-white" },
            { label: "Avg Competency", value: results.length > 0 ? `${avgScore}%` : "—", color: "text-blue-400" },
            { label: "Promotion Pools", value: results.length > 0 ? promotionReadyCount : "—", color: "text-emerald-400" },
            { label: "Coaching Needs", value: results.length > 0 ? needCoaching : "—", color: "text-amber-400" },
          ].map((s) => (
            <div key={s.label} className="bg-[#0d1527] border border-white/[0.06] rounded-xl p-3 md:p-5 shadow-xl">
              <div className="text-slate-400 text-[9px] md:text-[10px] font-bold uppercase tracking-wider">{s.label}</div>
              <div className={`text-xl md:text-3xl font-bold tracking-tight mt-1 md:mt-2 ${s.color}`}>{s.value}</div>
            </div>
          ))}
        </div>

        {error && (
          <div className="bg-rose-500/10 border border-rose-500/20 rounded-xl p-4 text-rose-400 text-xs md:text-sm animate-fadeIn">⚠️ {error}</div>
        )}

        {/* 📦 Phase 1: Pre-Analysis Management Registry Feed */}
        {results.length === 0 && !loading && (
          <div className="bg-[#0d1527] border border-white/[0.06] rounded-xl shadow-2xl overflow-hidden">
            <div className="p-4 md:p-6 border-b border-white/[0.06] bg-[#111b33]/20">
              <h2 className="text-white font-semibold text-sm md:text-base">Target Leadership Pipeline Candidates</h2>
              <p className="text-slate-400 text-[11px] mt-0.5">Identified corporate accounts scheduled for evaluation processing</p>
            </div>

            {fetching ? (
              <div className="text-center py-16 text-slate-400 text-xs flex flex-col items-center gap-3">
                <span className="w-5 h-5 border-2 border-white/20 border-t-blue-500 rounded-full animate-spin" />
                Querying Leadership Directory...
              </div>
            ) : managers.length === 0 ? (
              <div className="text-center py-16 px-4">
                <div className="text-2xl mb-2">👔</div>
                <div className="text-slate-400 text-sm">No management profiles found inside the active directory dataset.</div>
                <button onClick={() => router.push("/dashboard/employees")} className="mt-3 text-blue-400 text-xs hover:underline">→ Open Employee Roster Mapping</button>
              </div>
            ) : (
              <div className="divide-y divide-white/[0.04]">
                {managers.map((emp, i) => (
                  <div key={i} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-white/[0.01] transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-md bg-slate-800 border border-white/10 flex items-center justify-center text-xs font-bold text-slate-300">{emp.name.charAt(0)}</div>
                      <div>
                        <div className="text-white text-sm font-medium tracking-tight">{emp.name}</div>
                        <div className="text-slate-500 text-xs mt-0.5">{emp.role} · <span className="text-slate-400">{emp.department}</span></div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between sm:justify-end gap-4 border-t border-white/[0.04] sm:border-0 pt-2 sm:pt-0">
                      <span className="text-slate-400 font-mono text-xs hidden xs:inline-block">{emp.experience || "Fresh entry Tier"}</span>
                      <span className={`text-[9px] uppercase font-bold tracking-wider px-2 py-0.5 rounded border ${emp.status === "Active" ? "text-emerald-400 bg-emerald-500/10 border-emerald-500/20" : "text-amber-400 bg-amber-500/10 border-amber-500/20"}`}>{emp.status}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ⏳ Phase 2: Processing Engine Diagnostics Loader */}
        {loading && (
          <div className="bg-[#0d1527] border border-white/[0.06] rounded-xl p-12 text-center shadow-2xl max-w-xl mx-auto space-y-4">
            <div className="w-10 h-10 border-2 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto" />
            <div>
              <h3 className="text-white font-medium text-sm md:text-base">AI Leadership Assessment Running</h3>
              <p className="text-slate-400 text-xs mt-1">Parsing organizational matrices, technical expertise metrics, and capability history charts...</p>
            </div>
          </div>
        )}

        {/* 📊 Phase 3: Split Diagnostic Analytics Workspace View Dashboard */}
        {results.length > 0 && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* Left Panel: Scaled Interactive List Feed */}
            <div className="lg:col-span-5 space-y-3 order-2 lg:order-1">
              <div className="flex items-center justify-between mb-1 px-1">
                <h3 className="text-slate-400 text-xs font-bold uppercase tracking-wider">Leadership Breakdown</h3>
                <button onClick={() => { setResults([]); setSelected(null); }} className="text-xs text-rose-400 hover:text-rose-300">Clear Audit Logs</button>
              </div>

              <div className="space-y-2.5">
                {results.map((manager, index) => {
                  const isSelected = selected?.name === manager.name;
                  return (
                    <div
                      key={index}
                      onClick={() => setSelected(manager)}
                      className={`w-full text-left bg-[#0d1527] border rounded-xl p-4 cursor-pointer transition-all duration-150 ${isSelected ? "border-blue-500 bg-blue-500/[0.02] ring-1 ring-blue-500/30" : "border-white/[0.06] hover:border-white/20"}`}
                    >
                      <div className="flex justify-between items-start gap-2 mb-3">
                        <div>
                          <h4 className="text-white font-semibold text-sm tracking-tight">{manager.name}</h4>
                          <p className="text-slate-500 text-xs mt-0.5">{manager.department}</p>
                        </div>
                        <div className="text-right shrink-0">
                          <span className="text-blue-400 font-mono font-bold text-base">{manager.leadershipScore}</span>
                          <span className="text-slate-600 text-[10px] font-mono ml-0.5">/100</span>
                        </div>
                      </div>

                      <div className="w-full bg-slate-950 h-1 rounded-full mb-3 overflow-hidden border border-white/[0.02]">
                        <div
                          className={`h-full rounded-full transition-all duration-500 ${manager.leadershipScore >= 80 ? "bg-emerald-400" : manager.leadershipScore >= 60 ? "bg-blue-400" : "bg-amber-400"}`}
                          style={{ width: `${manager.leadershipScore}%` }}
                        />
                      </div>

                      <div className="flex flex-wrap gap-1">
                        {manager.promotionReady && <span className="text-[9px] uppercase font-extrabold tracking-wider bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded">↑ Promotion Ready</span>}
                        {manager.coachingNeeded && <span className="text-[9px] uppercase font-extrabold tracking-wider bg-amber-500/10 border border-amber-500/20 text-amber-400 px-1.5 py-0.5 rounded">Coaching Needed</span>}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Right Panel: Detail Report Engine */}
            <div className="lg:col-span-7 order-1 lg:order-2 sticky lg:top-24">
              {selected ? (
                <div className="bg-[#0d1527] border border-white/[0.06] rounded-xl p-5 md:p-6 shadow-2xl space-y-6 animate-fadeIn">
                  
                  {/* Card Section Identification Header */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/[0.06] pb-4">
                    <div>
                      <h2 className="text-white font-bold text-lg md:text-xl tracking-tight">{selected.name}</h2>
                      <p className="text-slate-400 text-xs mt-0.5">Operational Department Grouping: <span className="text-slate-200 font-medium">{selected.department}</span></p>
                    </div>
                    <span className={`text-[10px] uppercase font-bold tracking-wider px-3 py-1 rounded-md border self-start sm:self-center ${riskColor[selected.riskLevel]}`}>
                      {selected.riskLevel} Attrition Risk
                    </span>
                  </div>

                  {/* Core Metrics Layer */}
                  <div className="grid grid-cols-3 gap-3">
                    <div className="bg-slate-900/60 border border-white/[0.04] rounded-xl p-3.5 text-center">
                      <div className="text-slate-500 text-[9px] uppercase font-bold tracking-wider mb-1">Index Score</div>
                      <div className="text-blue-400 text-xl md:text-2xl font-black font-mono">{selected.leadershipScore}</div>
                    </div>
                    <div className={`border rounded-xl p-3.5 text-center transition-colors ${selected.promotionReady ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" : "bg-slate-900/40 border-white/[0.04] text-slate-500"}`}>
                      <div className="text-[9px] uppercase font-bold tracking-wider mb-1">Promotion</div>
                      <div className="text-xs md:text-sm font-bold tracking-tight">{selected.promotionReady ? "✓ Approved" : "Hold"}</div>
                    </div>
                    <div className={`border rounded-xl p-3.5 text-center transition-colors ${selected.coachingNeeded ? "bg-amber-500/10 border-amber-500/20 text-amber-400" : "bg-slate-900/40 border-white/[0.04] text-slate-500"}`}>
                      <div className="text-[9px] uppercase font-bold tracking-wider mb-1">Coaching</div>
                      <div className="text-xs md:text-sm font-bold tracking-tight">{selected.coachingNeeded ? "⚠ Required" : "Satisfactory"}</div>
                    </div>
                  </div>

                  {/* Strengths & Weaknesses Structured Data Blocks */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-slate-900/30 border border-white/[0.04] p-4 rounded-xl space-y-2.5">
                      <h4 className="text-[10px] text-slate-400 font-bold uppercase tracking-wider border-b border-white/[0.04] pb-1.5">Evaluated Strengths</h4>
                      {selected.strengths.map((s, i) => (
                        <div key={i} className="text-emerald-400 text-xs font-medium flex items-start gap-1.5 leading-relaxed">
                          <span className="mt-0.5 shrink-0">✓</span> <span>{s}</span>
                        </div>
                      ))}
                    </div>

                    <div className="bg-slate-900/30 border border-white/[0.04] p-4 rounded-xl space-y-2.5">
                      <h4 className="text-[10px] text-slate-400 font-bold uppercase tracking-wider border-b border-white/[0.04] pb-1.5">Identified Risks & Concerns</h4>
                      {selected.concerns.map((c, i) => (
                        <div key={i} className="text-rose-400 text-xs font-medium flex items-start gap-1.5 leading-relaxed">
                          <span className="mt-0.5 shrink-0">⚠</span> <span>{c}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* AI Recommendation Strategy Panel Footer */}
                  <div className="space-y-2">
                    <h4 className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Strategic Recommendation Vector</h4>
                    <div className="bg-blue-500/10 border border-blue-500/20 text-slate-200 text-xs leading-relaxed p-4 rounded-xl font-medium tracking-wide">
                      💡 {selected.recommendation}
                    </div>
                  </div>

                </div>
              ) : (
                <div className="bg-[#0d1527]/40 border border-white/[0.04] rounded-xl p-8 text-center text-slate-500 text-xs">
                  Select a leadership profile on the left terminal view to load complete automated analysis breakdown details.
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}