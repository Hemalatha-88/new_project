"use client";
import { useState, useEffect } from "react";

// ... (Keep your existing Interfaces here) ...
// --- ADD THIS INTERFACE ---
interface Employee {
  id: number;
  name: string;
  role: string;
  status: string;
  department?: string;
}

interface AttritionResult {
  name: string;
  riskScore: number;
  primaryReasons: string[];
  retentionActions: string[];
}
// --------------------------

export default function AttritionPage() {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<AttritionResult[]>([]);
  const [error, setError] = useState("");
  const [analyzed, setAnalyzed] = useState(false);
  const [selected, setSelected] = useState<AttritionResult | null>(null);

  useEffect(() => {
    fetch("https://hrms-ai-5.onrender.com/employees")
      .then((res) => res.json())
      .then(setEmployees)
      .catch(() => setError("Failed to connect to database"));
  }, []);

  const analyzeAttrition = async () => {
    setLoading(true);
    setError("");
    try {
      const res = await fetch("https://hrms-ai-5.onrender.com/attrition-bridge", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(employees),
      });

      const list = await res.json();

      if (!Array.isArray(list)) {
        throw new Error("Invalid data format received from server");
      }

      const sorted = [...list].sort((a, b) => b.riskScore - a.riskScore);
      setResults(sorted);
      setAnalyzed(true);
      if (sorted.length > 0) setSelected(sorted[0]);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#070b16] text-slate-100 p-8">
      <header className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-white">Attrition War Room</h1>
          <p className="text-slate-400 text-sm">Predictive Retention Engine</p>
        </div>
        <button 
          onClick={analyzeAttrition}
          className="bg-rose-600 px-6 py-2 rounded-lg font-bold hover:bg-rose-500 transition"
        >
          {loading ? "Processing..." : "Run Risk Diagnostics"}
        </button>
      </header>

      {error && <div className="p-4 mb-6 bg-red-500/10 border border-red-500/50 text-red-400 rounded-lg">{error}</div>}

      <div className="grid grid-cols-12 gap-6">
        {/* Registry */}
        <div className="col-span-12 xl:col-span-4 bg-[#0d1527] border border-white/10 rounded-xl overflow-hidden">
          <div className="p-4 border-b border-white/10 font-bold uppercase text-xs text-slate-400">Employee Registry</div>
          <div className="max-h-[600px] overflow-y-auto">
            {employees.map((e) => (
              <div key={e.id} className="p-4 border-b border-white/5 flex justify-between items-center">
                <div><div className="text-sm font-medium">{e.name}</div><div className="text-[10px] text-slate-500">{e.role}</div></div>
                <span className={`text-[10px] px-2 py-0.5 rounded ${e.status === 'Active' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'}`}>{e.status}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Analysis */}
        <div className="col-span-12 xl:col-span-8">
          {analyzed ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-3">
                {results.map((r, i) => (
                  <button key={i} onClick={() => setSelected(r)} className={`w-full p-4 rounded-xl border ${selected?.name === r.name ? 'border-blue-500 bg-blue-900/20' : 'border-white/10'}`}>
                    <div className="flex justify-between items-center">
                      <span className="font-semibold text-sm">{r.name}</span>
                      <span className={r.riskScore > 70 ? 'text-rose-400' : 'text-amber-400'}>{r.riskScore}% Risk</span>
                    </div>
                  </button>
                ))}
              </div>
              {selected && (
                <div className="bg-[#0d1527] border border-white/10 p-6 rounded-xl space-y-6">
                  <h2 className="text-xl font-bold">{selected.name}</h2>
                  <div>
                    <h3 className="text-[10px] uppercase font-bold text-slate-500">Why They May Leave</h3>
                    <ul className="list-disc list-inside text-sm text-slate-300 mt-2">{selected.primaryReasons.map((r, i) => <li key={i}>{r}</li>)}</ul>
                  </div>
                  <div>
                    <h3 className="text-[10px] uppercase font-bold text-emerald-500">Retention Actions</h3>
                    <ul className="space-y-2 mt-2">{selected.retentionActions.map((a, i) => <li key={i} className="text-sm text-emerald-300 bg-emerald-900/10 p-2 rounded">{a}</li>)}</ul>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="h-64 flex items-center justify-center border-2 border-dashed border-white/10 rounded-xl text-slate-500">
              Run diagnostics to populate the risk matrix
            </div>
          )}
        </div>
      </div>
    </div>
  );
}