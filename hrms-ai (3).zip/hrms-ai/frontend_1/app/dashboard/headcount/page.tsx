"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";

interface Employee { id: number; name: string; department: string; }
interface Analysis { department: string; current: number; required: number; gap: number; }

export default function HeadcountPlanner() {
  const router = useRouter();
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [analysis, setAnalysis] = useState<Analysis[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetch("https://hrms-ai-5.onrender.com/employees")
      .then(res => res.json())
      .then(data => setEmployees(data))
      .catch(console.error);
  }, []);

  const runForecast = async () => {
    setLoading(true);
    try {
      const res = await fetch("https://hrms-ai-5.onrender.com/forecast-bridge", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(employees),
      });
      const data = await res.json();
      setAnalysis(data);
    } catch (e) {
      console.error("Forecast error:", e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-4 md:p-8 font-sans">
      {/* Header */}
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <button onClick={() => router.push("/dashboard")} className="text-slate-500 text-xs hover:text-blue-400 mb-2 block">← Back to Command Center</button>
          <h1 className="text-2xl md:text-4xl font-extrabold tracking-tight">Workforce Insights</h1>
        </div>
        <button 
          onClick={runForecast} 
          className="w-full md:w-auto bg-blue-600 hover:bg-blue-500 text-white px-6 py-3 rounded-lg font-semibold shadow-lg shadow-blue-900/20 transition-all active:scale-95"
        >
          {loading ? "Analyzing..." : "Generate AI Forecast"}
        </button>
      </header>

      {/* Analysis Cards */}
      {analysis.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          {analysis.map((item, i) => (
            <div key={i} className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl">
              <h3 className="text-blue-400 font-bold text-lg mb-3">{item.department}</h3>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-slate-400">Current</span>
                <span className="font-mono text-lg">{item.current}</span>
              </div>
              <div className="flex justify-between text-sm mb-4">
                <span className="text-slate-400">Target</span>
                <span className="font-mono text-lg text-emerald-400">{item.required}</span>
              </div>
              <div className="bg-slate-950 p-3 rounded-lg flex items-center justify-between border border-slate-800">
                <span className="text-[10px] uppercase tracking-widest text-slate-500">Net Gap</span>
                <span className="text-xl font-black">{item.gap > 0 ? `+${item.gap}` : "0"}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Employee List */}
      <section>
        <h2 className="text-lg font-bold mb-4 text-slate-400">Active Directory ({employees.length})</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
          {employees.map(emp => (
            <div key={emp.id} className="bg-slate-900 p-4 rounded-xl border border-slate-800 flex justify-between items-center hover:border-slate-700 transition-colors">
              <div>
                <p className="font-medium text-sm">{emp.name}</p>
                <p className="text-[10px] text-blue-400 uppercase tracking-wider">{emp.department}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}