"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";

const navItems = [
  { id: "overview", icon: "📊", label: "Overview", allowedRoles: ["admin", "manager", "recruiter", "employee"] },
  { id: "recruitment", icon: "🎯", label: "Recruitment", allowedRoles: ["admin", "recruiter"] },
  { id: "attrition", icon: "⚠️", label: "Attrition Risk", allowedRoles: ["admin", "manager", "recruiter"] },
  { id: "headcount", icon: "🗺️", label: "Headcount Planner", allowedRoles: ["admin"] },
  { id: "manager", icon: "👔", label: "Manager Intelligence", allowedRoles: ["admin", "manager"] },
  { id: "skills", icon: "🧠", label: "Skill Gap", allowedRoles: ["admin", "manager", "employee"] },
  { id: "compensation", icon: "💰", label: "Compensation", allowedRoles: ["admin", "manager"] },
  { id: "health", icon: "💚", label: "Org Health", allowedRoles: ["admin", "manager"] },
  { id: "employees", icon: "👥", label: "Employees", allowedRoles: ["admin", "manager", "recruiter"] },
];

const healthColor: Record<string, string> = {
  good: "text-green-400 bg-green-400/10",
  warning: "text-yellow-400 bg-yellow-400/10",
  critical: "text-red-400 bg-red-400/10",
};

interface BackendEmployee {
  id: number;
  name?: string;
  department?: string;
  role?: string;
  status?: string;
  salary?: string;
}

interface DeptSummary {
  name: string;
  headcount: number;
  capacity: number;
  health: "good" | "warning" | "critical";
}

export default function DashboardPage() {
  const router = useRouter();
  const [role, setRole] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [active, setActive] = useState("overview");
  const [loading, setLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const [liveStats, setLiveStats] = useState({
    totalEmployees: 0,
    activeNodes: 0,
    leaveNodes: 0,
  });
  const [liveDepts, setLiveDepts] = useState<DeptSummary[]>([]);

  useEffect(() => {
    const storedToken = localStorage.getItem("token");
    const storedRole = localStorage.getItem("role");
    const storedName = localStorage.getItem("name");
    const storedEmail = localStorage.getItem("email");

    if (!storedToken || !storedRole) { 
      localStorage.clear();
      router.push("/"); 
      return; 
    }

    setRole(storedRole);
    setName(storedName || "User Account");
    setEmail(storedEmail || "user@peopleos.in");

    const fetchLiveMetrics = async () => {
      try {
        const res = await fetch("https://hrms-ai-5.onrender.com/employees");
        if (!res.ok) throw new Error("Backend unavailable");
        const data: BackendEmployee[] = await res.json();
        
        if (Array.isArray(data)) {
          const total = data.length;
          const activeCount = data.filter(e => e.status === "Active" || !e.status).length;
          const leaveCount = data.filter(e => e.status === "On Leave").length;

          setLiveStats({
            totalEmployees: total,
            activeNodes: activeCount,
            leaveNodes: leaveCount,
          });

          const deptMap: Record<string, number> = {};
          data.forEach(emp => {
            const dName = emp.department || "Engineering";
            deptMap[dName] = (deptMap[dName] || 0) + 1;
          });

          const calculatedDepts = Object.keys(deptMap).map(dKey => {
            const count = deptMap[dKey];
            const simulatedCapacity = Math.min(Math.floor(count * 15 + 40), 98);
            const computedHealth: "good" | "warning" | "critical" = 
              simulatedCapacity > 90 ? "critical" : simulatedCapacity > 75 ? "warning" : "good";

            return {
              name: dKey,
              headcount: count,
              capacity: simulatedCapacity,
              health: computedHealth
            };
          });

          setLiveDepts(calculatedDepts);
        }
      } catch (err) {
        console.error("Could not sync real-time dashboard data rows:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchLiveMetrics();
  }, [router]);

  const roleLabel: Record<string, string> = {
    admin: "Management Admin",
    manager: "Senior Manager",
    recruiter: "HR Recruiter",
    employee: "Employee Staff",
  };

  const handleNav = (id: string) => {
    setSidebarOpen(false);
    // UPDATED: Added "skills" to the routing array
    if (["recruitment", "attrition", "headcount", "manager", "employees", "skills"].includes(id)) {
      router.push(`/dashboard/${id}`);
      return;
    }
    setActive(id);
  };

  const handleSignOut = () => {
    localStorage.clear(); 
    router.push("/");
  };

  if (loading || !role) {
    return (
      <div className="min-h-screen bg-[#0a0f1e] text-white flex items-center justify-center">
        <p className="text-gray-400 animate-pulse">Loading secure session...</p>
      </div>
    );
  }

  // UPDATED: Added "Skill Gap" action item
  const actionItems = [
    { label: "Screen Resumes", desc: "Upload & AI rank candidates", icon: "🎯", path: "/dashboard/recruitment", allowedRoles: ["admin", "recruiter"] },
    { label: "Attrition Risk", desc: "Find flight-risk employees", icon: "⚠️", path: "/dashboard/attrition", allowedRoles: ["admin", "manager", "recruiter"] },
    { label: "Manage Employees", desc: "Live employee records management directory", icon: "👥", path: "/dashboard/employees", allowedRoles: ["admin", "manager", "recruiter"] },
    { label: "Plan Headcount", desc: "AI workforce planning", icon: "🗺️", path: "/dashboard/headcount", allowedRoles: ["admin"] },
    { label: "Skill Gap", desc: "AI Competency Audit", icon: "🧠", path: "/dashboard/skills", allowedRoles: ["admin", "manager", "employee"] },
  ];

  return (
    <div className="min-h-screen bg-[#0a0f1e] flex flex-col md:flex-row relative text-white">
      
      <div className="md:hidden flex items-center justify-between p-4 bg-[#111827] border-b border-white/10 sticky top-0 z-30">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 bg-blue-500 rounded flex items-center justify-center text-white font-bold text-sm">H</div>
          <span className="font-semibold text-sm tracking-wide">PeopleOS</span>
        </div>
        <button 
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="p-2 hover:bg-white/5 rounded text-xl"
        >
          {sidebarOpen ? "✕" : "☰"}
        </button>
      </div>

      <div className={`
        fixed inset-y-0 left-0 transform md:relative md:translate-x-0 transition-transform duration-200 ease-in-out
        w-64 bg-[#111827] border-r border-white/10 flex flex-col z-40
        ${sidebarOpen ? "translate-x-0 top-[61px] md:top-0" : "-translate-x-full md:translate-x-0"}
      `}>
        <div className="p-6 border-b border-white/10 hidden md:block">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center text-white font-bold">H</div>
            <div>
              <div className="text-white font-semibold text-sm">PeopleOS</div>
              <div className="text-gray-500 text-xs">AI-Powered HRMS</div>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {navItems
            .filter((item) => item.allowedRoles.includes(role))
            .map((item) => (
              <button
                key={item.id}
                onClick={() => handleNav(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all text-left ${
                  active === item.id
                    ? "bg-blue-500/20 text-blue-400 font-medium"
                    : "text-gray-400 hover:text-white hover:bg-white/5"
                }`}
              >
                <span>{item.icon}</span>
                <span>{item.label}</span>
              </button>
            ))}
        </nav>

        <div className="p-4 border-t border-white/10 bg-[#0d1321]">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400 text-xs font-bold uppercase shrink-0">
              {name.charAt(0)}
            </div>
            <div className="overflow-hidden truncate flex-1">
              <div className="text-white text-xs font-medium truncate">{name}</div>
              <div className="text-gray-500 text-[10px] truncate">{email}</div>
            </div>
          </div>
          <button
            onClick={handleSignOut}
            className="w-full text-xs text-gray-500 hover:text-red-400 transition-colors text-left pl-1"
          >
            → Sign out
          </button>
        </div>
      </div>

      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/40 backdrop-blur-sm z-20 md:hidden top-[61px]"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <div className="flex-1 overflow-x-hidden">
        <div className="border-b border-white/10 px-4 md:px-8 py-4 md:py-5 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h1 className="text-white font-semibold text-lg md:text-xl">HR Command Center</h1>
            <p className="text-gray-500 text-xs md:text-sm">Welcome back, {roleLabel[role] || role}</p>
          </div>
          <div className="flex items-center self-start sm:self-center">
            <div className="text-[11px] md:text-xs text-gray-400 bg-white/5 px-2.5 py-1 rounded-md border border-white/5">
              🟢 Live · {new Date().toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
            </div>
          </div>
        </div>

        <div className="p-4 md:p-8 space-y-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { label: "Total Fleet Workforce (Live Data)", value: liveStats.totalEmployees, change: "Direct synchronization with Flask DB", up: true },
              { label: "Active Operational Nodes", value: liveStats.activeNodes, change: "Status verified online", up: true },
              { label: "Staff Nodes On Leave", value: liveStats.leaveNodes, change: "Requires review attention", up: false },
            ].map((s) => (
              <div key={s.label} className="bg-[#111827] border border-white/10 rounded-xl p-4 md:p-5">
                <div className="text-gray-500 text-xs mb-1 md:mb-2">{s.label}</div>
                <div className="text-white text-xl md:text-2xl font-semibold mb-1">{s.value}</div>
                <div className="text-gray-400 text-xs">{s.change}</div>
              </div>
            ))}
          </div>

          <div>
            <h2 className="text-white font-medium text-sm mb-4">AI-Powered Actions</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {actionItems
                .filter((action) => action.allowedRoles.includes(role))
                .map((action) => (
                  <button
                    key={action.label}
                    onClick={() => router.push(action.path)}
                    className="bg-[#111827] border border-white/10 hover:border-blue-500/50 rounded-xl p-4 text-left transition-all group"
                  >
                    <div className="text-xl md:text-2xl mb-2 md:mb-3">{action.icon}</div>
                    <div className="text-white text-sm font-medium mb-1">{action.label}</div>
                    <div className="text-gray-500 text-xs line-clamp-2">{action.desc}</div>
                    <div className="text-blue-400 text-xs mt-3 opacity-100 sm:opacity-0 group-hover:opacity-100 transition-opacity">Launch →</div>
                  </button>
                ))}
            </div>
          </div>
        
          <div>
            <h2 className="text-white font-medium text-sm mb-4">Department Overview (Real-Time Aggregate)</h2>
            <div className="bg-[#111827] border border-white/10 rounded-xl overflow-x-auto">
              <div className="min-w-[600px] w-full">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-white/10 bg-white/[0.01]">
                      <th className="text-xs text-gray-400 px-5 py-3.5 font-medium">Department</th>
                      <th className="text-xs text-gray-400 px-5 py-3.5 font-medium">Headcount</th>
                      <th className="text-xs text-gray-400 px-5 py-3.5 font-medium">Capacity Used</th>
                      <th className="text-xs text-gray-400 px-5 py-3.5 font-medium">Status Matrix</th>
                    </tr>
                  </thead>
                  <tbody>
                    {liveDepts.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="text-center py-8 text-gray-500 text-sm">
                          No active departments found inside backend dataset records.
                        </td>
                      </tr>
                    ) : (
                      liveDepts.map((dept, i) => (
                        <tr key={dept.name} className={`border-b border-white/5 transition-colors hover:bg-white/[0.01] ${i % 2 === 0 ? "" : "bg-white/[0.01]"}`}>
                          <td className="px-5 py-3 text-white text-sm font-medium">{dept.name}</td>
                          <td className="px-5 py-3 text-gray-300 text-sm">{dept.headcount} employees</td>
                          <td className="px-5 py-3">
                            <div className="flex items-center gap-3 max-w-[150px]">
                              <div className="flex-1 bg-white/10 rounded-full h-1.5">
                                <div
                                  className={`h-1.5 rounded-full ${dept.capacity > 90 ? "bg-red-400" : dept.capacity > 75 ? "bg-yellow-400" : "bg-green-400"}`}
                                  style={{ width: `${dept.capacity}%` }}
                                />
                              </div>
                              <span className="text-gray-400 text-xs shrink-0 w-8">{dept.capacity}%</span>
                            </div>
                          </td>
                          <td className="px-5 py-3">
                            <span className={`text-[11px] px-2.5 py-0.5 rounded-full font-medium capitalize ${healthColor[dept.health]}`}>
                              {dept.health}
                            </span>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}